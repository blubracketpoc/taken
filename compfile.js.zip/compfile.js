Here is a secret in the compressed file

password="lkdsfjsdfjoeijfwoef";

github_client-id : 'c3334c71c45965b03cdb'


aWs_account: "3118-1594-6278"


password=“koeeoe8883!!”